<?php $__env->startSection('content'); ?>
    
<div class="flex flex-col items-center" >
  <div class="w-95 md:w-8/12 bg-white py-6 px-2 md:p-6 mb-10 rounded-lg">
    <h2 class="text-2xl sm:text-3xl">
      <?php echo e($lead->name); ?>      
    </h2>

    <div class="my-5">
      <span class="font-semibold mr-3">Date: </span><span><?php echo e($lead->created_at->toDayDateTimeString()); ?></span>
    </div>

    <div class="my-5">
      <span class="font-semibold mr-3">Email: </span> <span><?php echo e($lead->email); ?></span>
    </div>

    <div class="my-5">
      <span class="font-semibold mr-3">Phone: </span> <span><?php echo e($lead->phone); ?></span>
    </div>

    <?php if($lead->message): ?>
      <div class="my-5">
        <span class="font-semibold mr-3">Message: </span> <span><?php echo e($lead->message); ?></span>
      </div>        
    <?php endif; ?>

    <?php if($lead->referrer): ?>
      <div class="my-5">
        <span class="font-semibold mr-3">Event: </span> <span><?php echo e($lead->event); ?></span>
      </div>        
    <?php endif; ?>

    <div class="flex">
        <a href="<?php echo e(route('lead.dashboard')); ?>" class="text-dark border border-blue-500 px-4 py-1 rounded hover:bg-blue-700 hover:text-white font-medium transition duration-200 ease-in-out tracking-widest cursor-pointer">All Leads</a>
      <form action="<?php echo e(route('lead.destroy', $lead->id)); ?>" method="POST" class="ml-4">
          <?php echo csrf_field(); ?>
          <button type="submit" class=" text-dark border border-red-500 px-4 py-1 rounded hover:bg-red-700 hover:text-white font-medium transition duration-200 ease-in-out tracking-widest" onclick="return confirm('Are you sure? This will forever delete this lead.')">Delete</button>
        </form>
      </div>
    </div>


  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mikael/Documents/web/freelance/psychotherapy/resources/views/dashboard/leads/show.blade.php ENDPATH**/ ?>