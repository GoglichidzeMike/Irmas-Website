<?php $__env->startSection('content'); ?>
    

<div class="flex flex-col items-center" >

  <div class="w-95 md:w-8/12 bg-white text-center p-6 rounded-lg">
    <p>
      Dashboard
    </p> 
    <p>
      We will have some numbers here in the future.
    </p>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mikael/Documents/web.nosync/freelance/psychotherapy/resources/views/dashboard.blade.php ENDPATH**/ ?>