<!DOCTYPE html>
<html lang="en" style="scroll-behavior:smooth">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">

  <!-- Global site tag (gtag.js) - Google Analytics -->
  <script async src="https://www.googletagmanager.com/gtag/js?id=G-K2TNG6B0TL"></script>
  <script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());

    gtag('config', 'G-K2TNG6B0TL');
  </script>

  <!-- Global site tag (gtag.js) - Google Analytics -->


  <!-- Facebook Pixel Code -->
  <script>
    !function(f,b,e,v,n,t,s)
    {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
    n.callMethod.apply(n,arguments):n.queue.push(arguments)};
    if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
    n.queue=[];t=b.createElement(e);t.async=!0;
    t.src=v;s=b.getElementsByTagName(e)[0];
    s.parentNode.insertBefore(t,s)}(window, document,'script',
    'https://connect.facebook.net/en_US/fbevents.js');
    fbq('init', '2946443065626336');
    fbq('track', 'PageView');
  </script>
  <noscript><img height="1" width="1" style="display:none"
    src="https://www.facebook.com/tr?id=2946443065626336&ev=PageView&noscript=1"
  /></noscript>
  <!-- End Facebook Pixel Code -->


  <meta name="description" content="ფსიქოლოგია ყოველდღიურ ცხოვრებაში. კლინიკური ფსიქოლოგი ირმა კვაჭაძე" />
  
  <meta property="og:site_name"          content="Psychotherapy.ge ფსიქოლოგია ყოველდღიურ ცხოვრებაში" />
  <meta property="og:url"                contnet="<?php echo url()->current() ?>">
  <meta property="og:type"               content="website" />
  <meta property="og:title"              content="<?php echo e($title); ?>" />
  <meta property="og:locale"             content="ka_GE" />
  <meta property="og:description"        content="ფსიქოლოგია ყოველდღიურ ცხოვრებაში. კლინიკური ფსიქოლოგი ირმა კვაჭაძე" />
  <?php if(isset($image)): ?> <meta property="og:image"              content="<?php echo e($image); ?>" /><?php endif; ?>
  <?php if(empty($image)): ?> <meta property="og:image"              content="https://psychotherapy.ge/image/fb-share.jpg" /><?php endif; ?>
  
  
  <link rel="stylesheet preload" as="style" href="<?php echo e(asset('css/app.css')); ?>">

  <script src="/js/app.js" defer></script>
  <script src="/js/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous" rel="preload" as="script"></script>

  <title><?php echo e($title); ?></title>
</head>

<body class="bg-white min-h-screen flex justify-between flex-col overflow-visible">
  <a id="button"></a>
  <div class="nav w-full z-10 md:h-auto  overflow-hidden">
    <div class="py-4 w-95  xl:w-8/12 relative mx-auto md:flex justify-between items-center">
      <a href="<?php echo e(route('home')); ?>">
        <img src="/image/logo.png" class="w-10" alt="Irmas Logo">  
      </a>
        <div class="burger absolute top-3 right-2 md:hidden cursor-pointer">
          <div class="line1"></div>
          <div class="line2"></div>
          <div class="line3"></div>
        </div>
      <ul class="flex flex-col md:flex-row md:items-center text-primary space-y-2 my-4 md:m-0 md:space-x-6 md:space-y-0">
        <li>
          <a href="<?php echo e(route('home')); ?>" class="nav-link">მთავარი</a>
        </li>
        <li>
          <a href="<?php echo e(route('blogs')); ?>" class="nav-link">სტატიები</a>
        </li>
        <li>
          <a href="<?php echo e(route('events')); ?>" class="nav-link">ივენთები</a>
        </li>
        <li>
          <a href="<?php echo e(route('about')); ?>" class="nav-link">ჩემ შესახებ</a>  
        </li>
      </ul>
      <a href="/#contact" class="text-sm md:text-base bg-secondary py-2 px-8 shadow-md text-white rounded-xl hover:bg-primary hover:shadow-lg transition duration-300 ease-in-out focus:outline-none focus:ring-2 focus:ring-primary">კონტაქტი</a>
      </ul>
    </div>
  </div>

  <?php echo $__env->yieldContent('content'); ?>


  <footer class="mt-32 bg-primary w-full">
    <div class="w-full lg:w-8/12  px-4 lg:px-0 py-4 text-white mx-auto ">

      <ul class="text-sm align-center space-x-2 flex flex-row sm:justify-between">
        <div class="flex space-x-2">

          <div class="sm:flex sm:space-x-2">
            <li>
              <a href="<?php echo e(route('home')); ?>" class="text-sm sm:text-base py-3 hover:text-secondary focus:outline-none focus:text-secondary  transition duration-300 ease-out uppercase">მთავარი</a>
            </li>
            <div class="w-px h-auto bg-white bg-opacity-50 hidden sm:block"></div>
            <li>
              <a href="<?php echo e(route('blogs')); ?>" class="text-sm sm:text-base py-3 hover:text-secondary focus:outline-none focus:text-secondary  transition duration-300 ease-out uppercase">სტატიები</a>
            </li>
            <div class="w-px h-auto bg-white bg-opacity-50 hidden sm:block"></div>
          </div>
          <div class="sm:flex sm:space-x-2">
            <li>
              <a href="<?php echo e(route('events')); ?>" class="text-sm sm:text-base py-3 hover:text-secondary focus:outline-none focus:text-secondary  transition duration-300 ease-out uppercase">ივენთები</a>
            </li>
            <div class="w-px h-auto bg-white bg-opacity-50 hidden sm:block"></div>
            <li>
              <a href="<?php echo e(route('about')); ?>" class="text-sm sm:text-base py-3 hover:text-secondary  focus:outline-none focus:text-secondary transition duration-300 ease-out uppercase">ჩემ შესახებ</a>  
            </li>
          </div>
        </div>
          
        <div class="sm:flex sm:space-x-2 align-center">
          <li>
            <a href="<?php echo e(route('dashboard')); ?>" class="text-sm sm:text-base py-3 hover:text-secondary  focus:outline-none focus:text-secondary transition duration-300 ease-out uppercase">დეშბორდი</a>  
          </li>
          <div class="w-px h-auto bg-white bg-opacity-50 hidden sm:block"></div>
          <li>
            <a href="https://goglichidze.me" target="_blank" rel="nofollow noreferrer" class="text-sm sm:text-base py-3 hover:text-secondary  focus:outline-none focus:text-secondary transition duration-300 ease-out">&copy; Mikael</a>  
          </li>
        </div>
      </ul>
        
    </div>
  </footer>
</body>
</html><?php /**PATH /Users/mikael/Documents/web.nosync/freelance/psychotherapy/resources/views/layouts/home.blade.php ENDPATH**/ ?>