@extends('layouts.app')

@section('content')
    

<div class="flex flex-col items-center" >

  <div class="w-95 md:w-8/12 bg-white text-center p-6 rounded-lg">
    <p>
      Dashboard
    </p> 
    <p>
      We will have some numbers here in the future.
    </p>
  </div>
</div>

@endsection